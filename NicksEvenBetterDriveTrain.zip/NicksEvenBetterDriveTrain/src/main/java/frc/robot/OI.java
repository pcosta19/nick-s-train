package frc.robot;
import edu.wpi.first.wpilibj.Joystick;
public class OI
{
private static OI instance;
public static OI getInstance(){
    if (instance == null)
        instance = new OI();
    return instance;
}



public Joystick  leftJoystick = new Joystick(0);
public Joystick rightStick = new Joystick(1);







}
