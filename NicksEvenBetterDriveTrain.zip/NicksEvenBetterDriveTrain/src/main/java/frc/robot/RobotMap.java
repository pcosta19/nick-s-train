package frc.robot;

import edu.wpi.first.wpilibj.Joystick;

public class RobotMap
{
public static final int leftMotor = 0;
public static final int rightMotor = 1;
public static final int leftJoystick = 0;
public static final int rightJoystick = 1;

}