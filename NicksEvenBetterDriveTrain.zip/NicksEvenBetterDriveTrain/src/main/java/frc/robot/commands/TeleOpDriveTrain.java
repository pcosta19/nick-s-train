package frc.robot.commands;

import edu.wpi.first.wpilibj.command.Command;
import frc.robot.OI;
import frc.robot.subsystems.DriveTrain;
public class TeleOpDriveTrain extends Command {
    private boolean squaredInputs;
    public static TeleOpDriveTrain instance;
    public static TeleOpDriveTrain getInstance(){
        if (instance == null)
            instance = new TeleOpDriveTrain();
        return instance;
    }
    public TeleOpDriveTrain(){
        requires(DriveTrain.getInstance());
    }
    @Override
    protected void initialize(){
        squaredInputs = false;
    }
    public static double getLeftStick(){
        return (OI.getInstance().leftJoystick.getY());
    }
    public static double getRightStick(){
        return (OI.getInstance().rightStick.getY());
    }
    @Override
    protected void execute(){
        DriveTrain.getInstance().tankDrive(getLeftStick(), getRightStick(), squaredInputs);
    }
    @Override
    protected boolean isFinished(){
      return false; 
    }
    @Override
    public void end(){

    }
    @Override
    protected void interrupted(){
        
    }
}
