package frc.robot.subsystems;
import frc.robot.OI;
import frc.robot.RobotMap;
import edu.wpi.first.wpilibj.VictorSP;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.Timer;
import frc.robot.commands.TeleOpDriveTrain;
public class DriveTrain extends Subsystem {
private VictorSP leftMotorController;
private VictorSP rightMotorController;
private DifferentialDrive robotDrive;
public void initDefaultCommand(){
    setDefaultCommand(TeleOpDriveTrain.getInstance());
}
    private static DriveTrain instance;
    public static DriveTrain getInstance(){
        if (instance == null)
            instance = new DriveTrain();
        return instance;
    }
    public DriveTrain(){

    }
    public void tankDrive(double left, double right, boolean squaredInputs){
        robotDrive.tankDrive(left, right, false);
    }
    Timer timer = new Timer();
    public void driveLeftMotor(double speed, double time){
        leftMotorController.set(speed);
        Timer.delay(time);
        leftMotorController.set(0);
    }

    public void driveRightMotor(double speed, double time){
        rightMotorController.set(speed);
        Timer.delay(time);
        rightMotorController.set(0);
    }
    public void initialize(){
        leftMotorController = new VictorSP(RobotMap.leftMotor);
        rightMotorController = new VictorSP(RobotMap.rightMotor);
        robotDrive = new DifferentialDrive(leftMotorController, rightMotorController);
    }
}